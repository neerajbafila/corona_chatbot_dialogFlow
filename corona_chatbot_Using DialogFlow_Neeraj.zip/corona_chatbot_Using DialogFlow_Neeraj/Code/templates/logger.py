from datetime import datetime
from flask_pymongo import PyMongo
from pymongo import MongoClient
import json

with open('config.json', 'r') as c:
    params = json.load(c)['params']


class Log:
    def __init__(self):
        pass

    def write_log(self, sessionID, log_message):
        client = MongoClient(params['local_uri'])
        db = client.ChatBot
        log_message = {'bot says': log_message}
        db.logs.insert_one(log_message)

# ob = Log()
# test = {'Test': 'This is test'}
# ob.write_log(1, test)